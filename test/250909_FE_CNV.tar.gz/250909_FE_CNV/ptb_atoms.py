from ase.io import read, write
import os
import pandas as pd
import numpy as np
import pickle
import sys

from ase.neighborlist import NeighborList, natural_cutoffs
from ase.constraints import FixAtoms
 
def get_fix_indices(atoms, mult=1.3):
    """
    Get indices to perturb (indices) and fix (fix_indices);
    Input parameters:
        atoms: structure to perturb
        mult: multiplier for all cutoffs, useful for coarse grained adjustment;
    """
    cutoffs = natural_cutoffs(atoms, mult=mult)
    nl = NeighborList(cutoffs, self_interaction=False, bothways=True)
    nl.update(atoms)
    impurity_indice = [atom.index for atom in atoms if atom.symbol != "Fe"]
    # get indices near the impurity (interstitial C or TM solute)
    indices, offsets = nl.get_neighbors(impurity_indice[0])
    indices = list(indices)
    for impurity_index in impurity_indice:
        indices.insert(0, impurity_index)
    fix_indices = [atom.index for atom in atoms if atom.index not in indices]
    return indices, fix_indices

    """
    TWO WAYS TO PERTURBATE THE INITIAL STRUCTURE

    METHOD ONE; USE ASE's RATTLE FUNCTION;
    Atomic positions will be displaced randomly by a normal distribution;

    Setting stdev out of range(0.01, 0.30) is not recommended as
    the rattled structure is likely to converge with a shifted potential energy

    """

def rattle_atoms(atoms, stdev, fix_indices=None):
    """
    TWO WAYS TO USE RATTLE

    FIRST, rattle every atom in the structure;
    SECOND, rattle atoms near the impurity;
    If the second way is your matter of interest,
    get & tweak indices for fixing/rattling atoms with get_fix_indices;
    """

    atoms = atoms.copy()
    if fix_indices is not None:
        # fix atoms out of interest
        atoms.set_constraint(FixAtoms(fix_indices))
    # rattle atoms; rng=np.random ensures randomness
    # set seed=int for reproducibility
    atoms.rattle(stdev, rng=np.random) 
    # remove FixAtoms constraint
    atoms.constraints = None
    return atoms

    """
    METHOD NUMBER TWO; ADD DISPLACEMENTS in a range;
    This method could rather be more intuitive than ASE rattle,
    as we can directly set the range of displacements in angstrom unit;
    """

def displace_atom(atoms, index, min_disp=-0.5, max_disp=0.5):
    """
    Input Parameters:
        atoms: initial structure of interest
        index: index of the atom to perturb
        min_disp: min value of displacement for each atom; in Angstrom units
        max_disp: max value of displacement for each atom; in Angstrom units
    """
    atoms = atoms.copy()
    disp = np.random.uniform(min_disp, max_disp, size=3)
    pos = atoms.positions[index]
    # apply displacements to the atom
    atoms.positions[index] = pos + disp
    return atoms, disp 


UNCNV_DCT = {'uma': {'omat': ['b2', 'c1', 'e', 'f', 'i', 'k']},
             'esen': {'omat':['d', 'i', 'Ti'],
                      'oam': ['a2', 'b2', 'd', 'i', 'Mn', 'Ti']},
             }

def perturb_structures(model, modal):
    sandbox = os.path.join(os.getcwd(),model, modal)
    # unconverged configuration list
    uncnv_list = UNCNV_DCT[model][modal]

    # make directories to save perturbed structures
    rattle_dir=os.path.join(os.getcwd(),f'{model}/{modal}/rattle')
    disp_dir=os.path.join(os.getcwd(),f'{model}/{modal}/disp')
    os.makedirs(rattle_dir, exist_ok=True)
    os.makedirs(disp_dir, exist_ok=True)

    logger = open(f'{sandbox}/log.csv', 'w')
    logger.write(f'config,method,stdev,num_ptb,index,disp_x,disp_y,disp_z\n')

    for label in uncnv_list:
        init_atoms = read(f'{sandbox}/structure/POSCAR_{label}')
        # set a range of stdev for the rattle method
        indices, fix_indices = get_fix_indices(init_atoms, mult=1.3)

        # apply displacements
        atoms = init_atoms.copy()
        for i, index in enumerate(indices):
            atoms, disp = displace_atom(atoms, index)
            write(f'{sandbox}/disp/{label}_{i+1}', atoms, format='vasp')
            logger.write(f'{label},disp,0,{i+1},{index},{disp[0]},{disp[1]},{disp[2]}\n')


        # rattle initial structure
        stdev_list = [0.05, 0.075, 0.1, 0.125, 0.15, 0.175, 0.2, 0.225, 0.25]
        for stdev in stdev_list:
            logger.write(f'{label},rattle,{stdev},{len(indices)},-,-,-,-\n')
            atoms = init_atoms.copy()
            atoms = rattle_atoms(atoms, stdev, fix_indices=fix_indices)
            write(f'{sandbox}/rattle/{label}_{stdev}', atoms, format='vasp')

    logger.close()



if __name__ == '__main__':
    perturb_structures('uma', 'omat')
    perturb_structures('esen', 'omat')
    perturb_structures('esen', 'oam')
