"""
Modified based on Jinmu Yu's code
"""

from types import NotImplementedType
import warnings

from fairchem.core.units.mlip_unit import MLIPPredictUnit
# from fairchem.core.calculate.pretrained_mlip import get_isolated_atomic_energies
from fairchem.core.units.mlip_unit.api.inference import InferenceSettings
from fairchem.core import FAIRChemCalculator


HEAD = '/data2/shared_data/cps'

CALC_DCT = {
    'uma-m-1p1': f'{HEAD}/UMA/uma-m-1p1.pt',
    }

MODAL_DCT = {
    'omat': 'omat', # 'PBE',
    'omc':  'omc' # None,  # PBE-D3
    }

FUNC_DCT = {
    'omat': 'PBE',
    'omc':  'PBE', # 'PBE-D3' # None
    }
  
def return_calc():
    model = 'UMA'
    modal = task = 'omat'

    model_name = list(CALC_DCT.keys())[0]
    model_path =  CALC_DCT[model_name]

    print(f"[UMA] model={model_name}, modal(task_name)={modal}")
    print(f"[UMA] potential path: {model_path}")

    mlip_unit_kwargs = {
        'inference_model_path': model_path,
        'device': 'cuda',
        'inference_settings': InferenceSettings(
            external_graph_gen=False,
            ),
        }

    mlip_predict_unit = MLIPPredictUnit(**mlip_unit_kwargs)
    calc_uma = FAIRChemCalculator(
            predict_unit=mlip_predict_unit,
            task_name=MODAL_DCT[modal]
            )

    return calc_uma

if __name__  == '__main__':
    from ase.io import read, write
    from ase.filters import UnitCellFilter
    from ase.optimize import FIRE
 
    import gc, os, yaml

    model = 'uma'
    modal = 'omat'

    uncnv_list = ['b2', 'c1', 'e', 'f', 'i', 'k']
    stage = os.path.join(os.getcwd(), model, modal)

    for label in uncnv_list:
        print('carbon config: ',label)
        atoms = read(f'{stage}/structure/POSCAR_{label}', format='vasp')
        cell_filter = UnitCellFilter(atoms, mask=[1,1,1,0,0,0])
        opt = FIRE(cell_filter, logfile=f'{stage}/log/{label}_rerun.log')
        opt.run(fmax=1e-03, steps=500)
        write(f'{stage}/structure/CONTCAR_{label}_re', atoms, format='vasp')
        del cell_filter, opt
        gc.collect()
