#!/bin/bash
#SBATCH --job-name=debug
#SBATCH --output=std.%j  
#SBATCH --error=std.%j
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#SBATCH --time=24:00:00 
#SBATCH --partition=loki1

echo "SLURM_NTASKS: $SLURM_NTASKS"

source ~/.bash_profile

# pyright ptb_atoms.py
python ptb_atoms.py
