#!/bin/bash
#SBATCH --job-name=uma-re
#SBATCH --output=uma-re
#SBATCH --error=uma-re
#SBATCH --nodes=1   
#SBATCH --ntasks=1
#SBATCH --time=5:00:00 
#SBATCH --partition=gpu4
#SBATCH --gres=gpu:1

# export FLASH=1

echo "SLURM_NTASKS: $SLURM_NTASKS"

source ~/.bash_profile

if [ -z "$SLURM_NTASKS" ] || [ "$SLURM_NTASKS" -le 0 ]; then
	echo "Error: SLURM_NTASKS is not set or is less than or equal to 0"
	exit 1
fi

source ~/.bashrc


$PYTHON=PATH_TO_PYTHON_BIN
# environment 
$PYTHON -m venv omni_uma # python3.11
cd omni_uma/bin
source activate
module purge
module load CUDA/12.8.1
pip install fiarchem-core
pip install torch==2.7.0 --index-url https://download.pytorch.org/whl/cu128 

export TORCH_USE_CUDA_DSA=1

python uma_calculator.py
