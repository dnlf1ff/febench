"""
Modified based on Jinmu Yu's code
"""

from fairchem.core import OCPCalculator

HEAD = '/data2/shared_data/cps'

CALC_DCT = {
    'oam': f"{HEAD}/eSEN/esen_30m_oam.pt",
    'omat': f"{HEAD}/eSEN/esen_30m_omat.pt",
    }
 

def return_calc(modal):
    model = 'eSEN'
    model_path = CALC_DCT[modal]

    calc_kwargs = {
            'checkpoint_path': model_path,
            'cpu': False
            }

    print(f"[eSEN] model={model}, modal={modal}")
    print(f"[eSEN] potential path: {model_path}")

    calc = OCPCalculator(**calc_kwargs)
    return calc

if __name__ == '__main__':
    from ase.io import read, write
    from ase.filters import UnitCellFilter
    from ase.optimize import FIRE
    
    import gc, sys, os

    model = 'esen'
    modal = sys.argv[1]
    stage = os.path.join(os.getcwd(), model, modal)

    ESEN_UNCNV={'omat': {'carbon': ['d', 'i'], 'tm': ['Ti']},
                'oam': {'carbon': ['a2', 'b2', 'd', 'i'], 'tm': ['Mn', 'Ti']},
                }

    calc = return_calc(modal)
   
    # relax carbons
    for label in ESEN_UNCNV[modal]['carbon']:
        atoms = read(f'{stage}/structure/POSCAR_{label}', format='vasp')
        cell_filter = UnitCellFilter(atoms, mask=[1,1,1,0,0,0])
        opt = FIRE(cell_filter, logfile=f'{stage}/log/{label}_re.log')
        opt.run(fmax=1e-03, steps=500)
        write(f'{stage}/structure/CONTCAR_{label}_re', atoms, format='vasp')
        del cell_filter, opt

    # relax transition metal solutes
    for tm in ESEN_UNCNV[modal]['tm']:
        atoms = read(f'{stage}/structure/POSCAR_{tm}', format='vasp')
        cell_filter = UnitCellFilter(atoms, mask=[1,1,1,0,0,0])
        opt = FIRE(cell_filter, logfile=f'{stage}/log/{tm}_{tm}_1NN_re.log')
        opt.run(fmax=1e-03, steps=500)
        write(f'{stage}/structure/CONTCAR_{tm}', atoms, format='vasp')
        del cell_filter, opt

