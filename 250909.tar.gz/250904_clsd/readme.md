unconverged configurations in UMA-omat eSEN-oam, 
