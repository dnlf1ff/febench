SLURM_NTASKS: 1
sourcing ~/.bash_profile\n
Loading compiler version 2022.1.0
Loading tbb version 2021.9.0
Loading compiler-rt version 2023.1.0
Loading oclfpga version 2023.1.0
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL

Loading compiler/2022.1.0
  Loading requirement: tbb/latest compiler-rt/latest oclfpga/latest
Loading mkl version 2022.1.0
Loading mpi version 2021.6.0
/home/jinvk/environment/venv/n023/febench-mace/lib/python3.11/site-packages/e3nn/o3/_wigner.py:10: UserWarning: Environment variable TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD detected, since the`weights_only` argument was not explicitly passed to `torch.load`, forcing weights_only=False.
  _Jd, _W3j_flat, _W3j_indices = torch.load(os.path.join(os.path.dirname(__file__), 'constants.pt'))
/home/jinvk/environment/venv/n023/febench-mace/lib/python3.11/site-packages/mace/calculators/mace.py:197: UserWarning: Environment variable TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD detected, since the`weights_only` argument was not explicitly passed to `torch.load`, forcing weights_only=False.
  torch.load(f=model_path, map_location=device)
cuequivariance or cuequivariance_torch is not available. Cuequivariance acceleration will be disabled.
[MACE] model=mace-mpa-0-medium
[MACE] potential directory = /data2/shared_data/cps/MACE/mace-mpa-0-medium/mace-mpa-0-medium.model
Using head default out of ['default']
No dtype selected, switching to float64 to match model dtype.
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.87s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.87s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:08<00:00,  8.38s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:08<00:00,  8.38s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:20<04:51, 20.82s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [00:46<05:11, 23.93s/it]processing carbon in iron ...:  20%|██        | 3/15 [00:59<03:45, 18.82s/it]processing carbon in iron ...:  27%|██▋       | 4/15 [01:33<04:30, 24.56s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [01:50<03:39, 21.97s/it]processing carbon in iron ...:  40%|████      | 6/15 [02:08<03:05, 20.58s/it]processing carbon in iron ...:  47%|████▋     | 7/15 [02:27<02:39, 19.99s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [03:09<03:10, 27.17s/it]processing carbon in iron ...:  60%|██████    | 9/15 [03:45<02:58, 29.79s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [04:23<02:42, 32.54s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [04:56<02:10, 32.55s/it]processing carbon in iron ...:  80%|████████  | 12/15 [05:36<01:44, 34.71s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [06:50<01:33, 46.72s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [07:12<00:39, 39.14s/it]processing carbon in iron ...: 100%|██████████| 15/15 [07:32<00:00, 33.64s/it]processing carbon in iron ...: 100%|██████████| 15/15 [07:32<00:00, 30.20s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:13<01:48, 13.56s/it]processing transition metals ...:  22%|██▏       | 2/9 [00:27<01:34, 13.52s/it]processing transition metals ...:  33%|███▎      | 3/9 [00:40<01:20, 13.50s/it]processing transition metals ...:  44%|████▍     | 4/9 [00:53<01:06, 13.28s/it]processing transition metals ...:  56%|█████▌    | 5/9 [01:06<00:52, 13.07s/it]processing transition metals ...:  67%|██████▋   | 6/9 [01:25<00:45, 15.13s/it]processing transition metals ...:  78%|███████▊  | 7/9 [01:40<00:30, 15.28s/it]processing transition metals ...:  89%|████████▉ | 8/9 [01:59<00:16, 16.44s/it]processing transition metals ...: 100%|██████████| 9/9 [02:14<00:00, 16.00s/it]processing transition metals ...: 100%|██████████| 9/9 [02:14<00:00, 14.98s/it]
/home/jinvk/environment/venv/n023/febench-mace/lib/python3.11/site-packages/e3nn/o3/_wigner.py:10: UserWarning: Environment variable TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD detected, since the`weights_only` argument was not explicitly passed to `torch.load`, forcing weights_only=False.
  _Jd, _W3j_flat, _W3j_indices = torch.load(os.path.join(os.path.dirname(__file__), 'constants.pt'))
/home/jinvk/environment/venv/n023/febench-mace/lib/python3.11/site-packages/mace/calculators/mace.py:197: UserWarning: Environment variable TORCH_FORCE_NO_WEIGHTS_ONLY_LOAD detected, since the`weights_only` argument was not explicitly passed to `torch.load`, forcing weights_only=False.
  torch.load(f=model_path, map_location=device)
cuequivariance or cuequivariance_torch is not available. Cuequivariance acceleration will be disabled.
[MACE] model=mace-omat-0-medium
[MACE] potential directory = /data2/shared_data/cps/MACE/mace-omat-0-medium/mace-omat-0-medium.model
Using head default out of ['default']
No dtype selected, switching to float64 to match model dtype.
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.72s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.72s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:08<00:00,  8.47s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:08<00:00,  8.47s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:16<03:49, 16.37s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [00:39<04:27, 20.61s/it]processing carbon in iron ...:  20%|██        | 3/15 [00:55<03:38, 18.20s/it]processing carbon in iron ...:  27%|██▋       | 4/15 [01:19<03:47, 20.66s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [01:34<03:05, 18.60s/it]processing carbon in iron ...:  40%|████      | 6/15 [01:48<02:33, 17.06s/it]processing carbon in iron ...:  47%|████▋     | 7/15 [02:03<02:11, 16.43s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [02:38<02:36, 22.35s/it]processing carbon in iron ...:  60%|██████    | 9/15 [03:11<02:34, 25.71s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [03:51<02:29, 29.93s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [04:14<01:51, 27.99s/it]processing carbon in iron ...:  80%|████████  | 12/15 [04:50<01:30, 30.20s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [05:38<01:11, 35.63s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [06:03<00:32, 32.33s/it]processing carbon in iron ...: 100%|██████████| 15/15 [06:20<00:00, 27.80s/it]processing carbon in iron ...: 100%|██████████| 15/15 [06:20<00:00, 25.36s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:13<01:51, 13.95s/it]processing transition metals ...:  22%|██▏       | 2/9 [00:27<01:36, 13.84s/it]processing transition metals ...:  33%|███▎      | 3/9 [00:50<01:46, 17.83s/it]processing transition metals ...:  44%|████▍     | 4/9 [01:02<01:17, 15.42s/it]processing transition metals ...:  56%|█████▌    | 5/9 [01:21<01:06, 16.72s/it]processing transition metals ...:  67%|██████▋   | 6/9 [01:39<00:51, 17.28s/it]processing transition metals ...:  78%|███████▊  | 7/9 [01:52<00:31, 15.96s/it]processing transition metals ...:  89%|████████▉ | 8/9 [02:08<00:16, 16.04s/it]processing transition metals ...: 100%|██████████| 9/9 [02:22<00:00, 15.14s/it]processing transition metals ...: 100%|██████████| 9/9 [02:22<00:00, 15.78s/it]
