SLURM_NTASKS: 1
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
sourcing ~/.bash_profile\n
Removing mpi version 2021.6.0
Use `module list` to view any remaining dependent modules.
Removing mkl version 2022.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler version 2022.1.0
Use `module list` to view any remaining dependent modules.
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
Removing oclfpga version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler-rt version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing tbb version 2021.9.0
Use `module list` to view any remaining dependent modules.
Loading compiler version 2022.1.0
Loading tbb version 2021.9.0
Loading compiler-rt version 2023.1.0
Loading oclfpga version 2023.1.0
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL

Loading compiler/2022.1.0
  Loading requirement: tbb/latest compiler-rt/latest oclfpga/latest
Loading mkl version 2022.1.0
Loading mpi version 2021.6.0
/home/jinvk/environment/venv/n023/febench-orb/lib/python3.11/site-packages/orb_models/utils.py:30: UserWarning: Setting global torch default dtype to torch.float32.
  warnings.warn(f"Setting global torch default dtype to {torch_dtype}.")
/home/jinvk/environment/venv/n023/febench-orb/lib/python3.11/site-packages/orb_models/utils.py:32: UserWarning: Consider passing 'precision=float32-high' for significantly higher (>2x) model throughput if high precision is not required.
  warnings.warn(
/home/jinvk/environment/venv/n023/febench-orb/lib/python3.11/site-packages/torch/_inductor/compile_fx.py:236: UserWarning: TensorFloat32 tensor cores for float32 matrix multiplication available but not enabled. Consider setting `torch.set_float32_matmul_precision('high')` for better performance.
  warnings.warn(
[ORB] model=orb_v3_conservative_inf_mpa
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:04<00:00,  4.01s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:04<00:00,  4.01s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:04<00:00,  4.24s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:04<00:00,  4.24s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:10<02:25, 10.41s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [00:24<02:47, 12.86s/it]processing carbon in iron ...:  20%|██        | 3/15 [00:29<01:48,  9.07s/it]processing carbon in iron ...:  27%|██▋       | 4/15 [00:37<01:37,  8.82s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [00:43<01:16,  7.61s/it]processing carbon in iron ...:  40%|████      | 6/15 [00:52<01:11,  7.99s/it]processing carbon in iron ...:  47%|████▋     | 7/15 [00:59<01:02,  7.84s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [01:18<01:19, 11.39s/it]processing carbon in iron ...:  60%|██████    | 9/15 [01:32<01:12, 12.10s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [01:51<01:11, 14.24s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [02:07<00:59, 14.79s/it]processing carbon in iron ...:  80%|████████  | 12/15 [02:24<00:46, 15.45s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [02:57<00:41, 20.68s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [03:07<00:17, 17.51s/it]processing carbon in iron ...: 100%|██████████| 15/15 [03:15<00:00, 14.86s/it]processing carbon in iron ...: 100%|██████████| 15/15 [03:15<00:00, 13.07s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:05<00:45,  5.72s/it]processing transition metals ...:  22%|██▏       | 2/9 [00:13<00:47,  6.82s/it]processing transition metals ...:  33%|███▎      | 3/9 [00:24<00:51,  8.64s/it]processing transition metals ...:  44%|████▍     | 4/9 [00:30<00:38,  7.78s/it]processing transition metals ...:  56%|█████▌    | 5/9 [00:44<00:40, 10.12s/it]processing transition metals ...:  67%|██████▋   | 6/9 [00:53<00:28,  9.57s/it]processing transition metals ...:  78%|███████▊  | 7/9 [01:00<00:17,  8.73s/it]processing transition metals ...:  89%|████████▉ | 8/9 [01:08<00:08,  8.45s/it]processing transition metals ...: 100%|██████████| 9/9 [01:14<00:00,  7.74s/it]processing transition metals ...: 100%|██████████| 9/9 [01:14<00:00,  8.27s/it]
/home/jinvk/environment/venv/n023/febench-orb/lib/python3.11/site-packages/orb_models/utils.py:30: UserWarning: Setting global torch default dtype to torch.float32.
  warnings.warn(f"Setting global torch default dtype to {torch_dtype}.")
/home/jinvk/environment/venv/n023/febench-orb/lib/python3.11/site-packages/orb_models/utils.py:32: UserWarning: Consider passing 'precision=float32-high' for significantly higher (>2x) model throughput if high precision is not required.
  warnings.warn(
[ORB] model=orb_v3_conservative_inf_omat
Traceback (most recent call last):
  File "/home/jinvk/environment/venv/n023/febench-orb/bin/febench-tm", line 8, in <module>
    sys.exit(main())
             ^^^^^^
  File "/home/jinvk/__project__/2025/febench/febench/tm/script.py", line 95, in main
    process_tm(config, calc)
  File "/home/jinvk/__project__/2025/febench/febench/tm/script.py", line 25, in process_tm
    Fe_bulk = read(f'{config["pureFe"]["save"]}/structure/bulk_opt.extxyz')
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/jinvk/environment/venv/n023/febench-orb/lib/python3.11/site-packages/ase/io/formats.py", line 787, in read
    format = format or filetype(filename, read=isinstance(filename, str))
                       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/jinvk/environment/venv/n023/febench-orb/lib/python3.11/site-packages/ase/io/formats.py", line 962, in filetype
    fd = open_with_compression(filename, 'rb')
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/home/jinvk/environment/venv/n023/febench-orb/lib/python3.11/site-packages/ase/io/formats.py", line 591, in open_with_compression
    return open(filename, mode)
           ^^^^^^^^^^^^^^^^^^^^
FileNotFoundError: [Errno 2] No such file or directory: './orb/omat/./pureFe/structure/bulk_opt.extxyz'
