SLURM_NTASKS: 1
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
sourcing ~/.bash_profile\n
Removing mpi version 2021.6.0
Use `module list` to view any remaining dependent modules.
Removing mkl version 2022.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler version 2022.1.0
Use `module list` to view any remaining dependent modules.
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
Removing oclfpga version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler-rt version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing tbb version 2021.9.0
Use `module list` to view any remaining dependent modules.
Loading compiler version 2022.1.0
Loading tbb version 2021.9.0
Loading compiler-rt version 2023.1.0
Loading oclfpga version 2023.1.0
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL

Loading compiler/2022.1.0
  Loading requirement: tbb/latest compiler-rt/latest oclfpga/latest
Loading mkl version 2022.1.0
Loading mpi version 2021.6.0
/home/jinvk/environment/venv/n023/febench-orb/lib/python3.11/site-packages/orb_models/utils.py:30: UserWarning: Setting global torch default dtype to torch.float32.
  warnings.warn(f"Setting global torch default dtype to {torch_dtype}.")
/home/jinvk/environment/venv/n023/febench-orb/lib/python3.11/site-packages/orb_models/utils.py:32: UserWarning: Consider passing 'precision=float32-high' for significantly higher (>2x) model throughput if high precision is not required.
  warnings.warn(
[ORB] model=orb_v3_conservative_inf_omat
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:15<00:00, 15.95s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:16<00:00, 16.31s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:03<00:00,  3.78s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:03<00:00,  3.78s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:08<02:04,  8.87s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [00:22<02:32, 11.71s/it]processing carbon in iron ...:  20%|██        | 3/15 [00:26<01:40,  8.34s/it]processing carbon in iron ...:  27%|██▋       | 4/15 [00:32<01:18,  7.11s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [00:37<01:04,  6.43s/it]processing carbon in iron ...:  40%|████      | 6/15 [00:45<01:02,  6.89s/it]processing carbon in iron ...:  47%|████▋     | 7/15 [00:51<00:53,  6.72s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [01:08<01:09,  9.98s/it]processing carbon in iron ...:  60%|██████    | 9/15 [01:22<01:06, 11.12s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [01:39<01:05, 13.17s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [02:05<01:08, 17.14s/it]processing carbon in iron ...:  80%|████████  | 12/15 [02:20<00:48, 16.28s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [02:47<00:39, 19.61s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [02:56<00:16, 16.52s/it]processing carbon in iron ...: 100%|██████████| 15/15 [03:03<00:00, 13.36s/it]processing carbon in iron ...: 100%|██████████| 15/15 [03:03<00:00, 12.20s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:07<00:59,  7.44s/it]processing transition metals ...:  22%|██▏       | 2/9 [00:13<00:48,  6.87s/it]processing transition metals ...:  33%|███▎      | 3/9 [00:21<00:41,  6.98s/it]processing transition metals ...:  44%|████▍     | 4/9 [00:28<00:35,  7.02s/it]processing transition metals ...:  56%|█████▌    | 5/9 [00:39<00:33,  8.42s/it]processing transition metals ...:  67%|██████▋   | 6/9 [00:51<00:28,  9.65s/it]processing transition metals ...:  78%|███████▊  | 7/9 [01:01<00:19,  9.89s/it]processing transition metals ...:  89%|████████▉ | 8/9 [01:14<00:10, 10.80s/it]processing transition metals ...: 100%|██████████| 9/9 [01:22<00:00,  9.93s/it]processing transition metals ...: 100%|██████████| 9/9 [01:22<00:00,  9.13s/it]
