SLURM_NTASKS: 1
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
sourcing ~/.bash_profile\n
Removing mpi version 2021.6.0
Use `module list` to view any remaining dependent modules.
Removing mkl version 2022.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler version 2022.1.0
Use `module list` to view any remaining dependent modules.
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
Removing oclfpga version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler-rt version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing tbb version 2021.9.0
Use `module list` to view any remaining dependent modules.
Loading compiler version 2022.1.0
Loading tbb version 2021.9.0
Loading compiler-rt version 2023.1.0
Loading oclfpga version 2023.1.0
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL

Loading compiler/2022.1.0
  Loading requirement: tbb/latest compiler-rt/latest oclfpga/latest
Loading mkl version 2022.1.0
Loading mpi version 2021.6.0
To get the best performance, it is recommended to adjust the number of threads by setting the environment variables OMP_NUM_THREADS, DP_INTRA_OP_PARALLELISM_THREADS, and DP_INTER_OP_PARALLELISM_THREADS. See https://deepmd.rtfd.io/parallelism/ for more information.
[DPA] model=dpa31-openlam, modal=MP_traj_v024_alldata_mixu
[DPA] potential directory = /data2/shared_data/cps/DPA3/DPA-3.1-3M.pt
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:55<07:24, 55.59s/it]processing transition metals ...:  22%|██▏       | 2/9 [01:16<04:08, 35.47s/it]processing transition metals ...:  33%|███▎      | 3/9 [01:33<02:39, 26.67s/it]processing transition metals ...:  44%|████▍     | 4/9 [01:54<02:02, 24.51s/it]processing transition metals ...:  56%|█████▌    | 5/9 [02:13<01:29, 22.49s/it]processing transition metals ...:  67%|██████▋   | 6/9 [02:32<01:03, 21.28s/it]processing transition metals ...:  78%|███████▊  | 7/9 [02:44<00:36, 18.27s/it]processing transition metals ...:  89%|████████▉ | 8/9 [02:59<00:17, 17.30s/it]processing transition metals ...: 100%|██████████| 9/9 [03:15<00:00, 16.91s/it]processing transition metals ...: 100%|██████████| 9/9 [03:15<00:00, 21.73s/it]
removing 32th Fe atom in [2.85261741 0.         0.        ]
removing 1th Fe atom in [1.4263087 1.4263087 1.4263087]
removing 32th Fe atom in [2.85261741 0.         0.        ]
removing 1th Fe atom in [1.4263087 1.4263087 1.4263087]
removing 32th Fe atom in [2.85261741 0.         0.        ]
removing 1th Fe atom in [1.4263087 1.4263087 1.4263087]
removing 32th Fe atom in [2.85261741 0.         0.        ]
removing 1th Fe atom in [1.4263087 1.4263087 1.4263087]
removing 32th Fe atom in [2.85261741 0.         0.        ]
removing 1th Fe atom in [1.4263087 1.4263087 1.4263087]
removing 32th Fe atom in [2.85261741 0.         0.        ]
removing 1th Fe atom in [1.4263087 1.4263087 1.4263087]
removing 32th Fe atom in [2.85261741 0.         0.        ]
removing 1th Fe atom in [1.4263087 1.4263087 1.4263087]
removing 32th Fe atom in [2.85261741 0.         0.        ]
removing 1th Fe atom in [1.4263087 1.4263087 1.4263087]
removing 32th Fe atom in [2.85261741 0.         0.        ]
removing 1th Fe atom in [1.4263087 1.4263087 1.4263087]
