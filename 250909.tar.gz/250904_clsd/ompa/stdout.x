GPU 2 assigned to the job
SLURM_NTASKS: 1
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
sourcing ~/.bash_profile\n
Removing mpi version 2021.6.0
Use `module list` to view any remaining dependent modules.
Removing mkl version 2022.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler version 2022.1.0
Use `module list` to view any remaining dependent modules.
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
Removing oclfpga version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler-rt version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing tbb version 2021.9.0
Use `module list` to view any remaining dependent modules.
Loading compiler version 2022.1.0
Loading tbb version 2021.9.0
Loading compiler-rt version 2023.1.0
Loading oclfpga version 2023.1.0
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL

Loading compiler/2022.1.0
  Loading requirement: tbb/latest compiler-rt/latest oclfpga/latest
Loading mkl version 2022.1.0
Loading mpi version 2021.6.0
[SevenNet] model=ompa, modal=omat24
[SevenNet] potential path: /data2/shared_data/cps/o50mp7a_ft/checkpoint_2.pth
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.70s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.70s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:10<00:00, 10.42s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:10<00:00, 10.42s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:33<07:52, 33.72s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [01:51<12:58, 59.85s/it]processing carbon in iron ...:  20%|██        | 3/15 [02:15<08:38, 43.19s/it]processing carbon in iron ...:  27%|██▋       | 4/15 [03:22<09:38, 52.56s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [03:56<07:39, 45.97s/it]processing carbon in iron ...:  40%|████      | 6/15 [04:31<06:21, 42.34s/it]processing carbon in iron ...:  47%|████▋     | 7/15 [05:10<05:29, 41.14s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [06:36<06:28, 55.51s/it]processing carbon in iron ...:  60%|██████    | 9/15 [07:52<06:10, 61.77s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [09:16<05:43, 68.70s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [10:34<04:46, 71.60s/it]processing carbon in iron ...:  80%|████████  | 12/15 [12:04<03:51, 77.08s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [14:10<03:04, 92.03s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [15:08<01:21, 81.85s/it]processing carbon in iron ...: 100%|██████████| 15/15 [15:47<00:00, 68.68s/it]processing carbon in iron ...: 100%|██████████| 15/15 [15:47<00:00, 63.14s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:17<02:22, 17.76s/it]processing transition metals ...:  22%|██▏       | 2/9 [00:35<02:02, 17.56s/it]processing transition metals ...:  33%|███▎      | 3/9 [00:56<01:55, 19.22s/it]processing transition metals ...:  44%|████▍     | 4/9 [01:12<01:30, 18.14s/it]processing transition metals ...:  56%|█████▌    | 5/9 [01:33<01:16, 19.14s/it]processing transition metals ...:  67%|██████▋   | 6/9 [02:00<01:05, 21.77s/it]processing transition metals ...:  78%|███████▊  | 7/9 [02:16<00:39, 19.69s/it]processing transition metals ...:  89%|████████▉ | 8/9 [02:38<00:20, 20.56s/it]processing transition metals ...: 100%|██████████| 9/9 [02:56<00:00, 19.79s/it]processing transition metals ...: 100%|██████████| 9/9 [02:56<00:00, 19.62s/it]
[SevenNet] model=ompa, modal=mpa
[SevenNet] potential path: /data2/shared_data/cps/o50mp7a_ft/checkpoint_2.pth
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.70s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.70s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:10<00:00, 10.63s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:10<00:00, 10.63s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:40<09:22, 40.18s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [01:50<12:33, 57.96s/it]processing carbon in iron ...:  20%|██        | 3/15 [02:07<07:52, 39.42s/it]processing carbon in iron ...:  27%|██▋       | 4/15 [03:07<08:41, 47.37s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [03:35<06:43, 40.39s/it]processing carbon in iron ...:  40%|████      | 6/15 [04:10<05:47, 38.64s/it]processing carbon in iron ...:  47%|████▋     | 7/15 [04:52<05:17, 39.63s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [06:08<05:57, 51.09s/it]processing carbon in iron ...:  60%|██████    | 9/15 [07:20<05:45, 57.65s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [08:32<05:10, 62.14s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [09:44<04:20, 65.15s/it]processing carbon in iron ...:  80%|████████  | 12/15 [11:01<03:26, 68.68s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [12:54<02:44, 82.18s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [13:46<01:13, 73.14s/it]processing carbon in iron ...: 100%|██████████| 15/15 [14:21<00:00, 61.65s/it]processing carbon in iron ...: 100%|██████████| 15/15 [14:21<00:00, 57.44s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:16<02:10, 16.31s/it]processing transition metals ...:  22%|██▏       | 2/9 [00:33<01:57, 16.83s/it]processing transition metals ...:  33%|███▎      | 3/9 [00:52<01:46, 17.71s/it]processing transition metals ...:  44%|████▍     | 4/9 [01:09<01:26, 17.33s/it]processing transition metals ...:  56%|█████▌    | 5/9 [01:33<01:19, 19.84s/it]processing transition metals ...:  67%|██████▋   | 6/9 [02:03<01:09, 23.26s/it]processing transition metals ...:  78%|███████▊  | 7/9 [02:20<00:42, 21.16s/it]processing transition metals ...:  89%|████████▉ | 8/9 [02:41<00:21, 21.24s/it]processing transition metals ...: 100%|██████████| 9/9 [03:01<00:00, 20.90s/it]processing transition metals ...: 100%|██████████| 9/9 [03:01<00:00, 20.17s/it]
