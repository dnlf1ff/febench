#!/bin/bash
#SBATCH --job-name=ompa
#SBATCH --output=ompa.x
#SBATCH --error=ompa.x
#SBATCH --nodes=1   
#SBATCH --ntasks=1
#SBATCH --time=3:00:00 
#SBATCH --partition=gpu2
#SBATCH --gres=gpu:1

echo "SLURM_NTASKS: $SLURM_NTASKS"

source ~/.bash_profile

if [ -z "$SLURM_NTASKS" ] || [ "$SLURM_NTASKS" -le 0 ]; then
	echo "Error: SLURM_NTASKS is not set or is less than or equal to 0"
	exit 1
fi


source $FE_SEVN_VENV/bin/activate
export FLASH=1

sleep 10
febench --calc ompa --modal omat24
sleep 10
febench --calc ompa --modal mpa
