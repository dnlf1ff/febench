#!/bin/bash
#SBATCH --job-name=data
#SBATCH --output=std.x
#SBATCH --error=std.x
#SBATCH --nodes=1
#SBATCH --ntasks-per-node=16
#SBATCH --time=24:00:00 
#SBATCH --partition=loki1

WDIR=/data2_1/jinvk/25_Fe/250904_clsd

MLIP=("ompa" "mace" "dpa" "esen" "orb" "uma" "omni")
