GPU 2 assigned to the job
SLURM_NTASKS: 1
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
sourcing ~/.bash_profile\n
Removing mpi version 2021.6.0
Use `module list` to view any remaining dependent modules.
Removing mkl version 2022.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler version 2022.1.0
Use `module list` to view any remaining dependent modules.
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
Removing oclfpga version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler-rt version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing tbb version 2021.9.0
Use `module list` to view any remaining dependent modules.
Loading compiler version 2022.1.0
Loading tbb version 2021.9.0
Loading compiler-rt version 2023.1.0
Loading oclfpga version 2023.1.0
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL

Loading compiler/2022.1.0
  Loading requirement: tbb/latest compiler-rt/latest oclfpga/latest
Loading mkl version 2022.1.0
Loading mpi version 2021.6.0
/home/jinvk/environment/venv/febench-esen/lib/python3.11/site-packages/fairchem/core/models/scn/spherical_harmonics.py:23: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  _Jd = torch.load(os.path.join(os.path.dirname(__file__), "Jd.pt"))
/home/jinvk/environment/venv/febench-esen/lib/python3.11/site-packages/fairchem/core/models/equiformer_v2/wigner.py:10: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  _Jd = torch.load(os.path.join(os.path.dirname(__file__), "Jd.pt"))
/home/jinvk/environment/venv/febench-esen/lib/python3.11/site-packages/fairchem/core/models/escn/so3.py:23: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  _Jd = torch.load(os.path.join(os.path.dirname(__file__), "Jd.pt"))
/home/jinvk/environment/venv/febench-esen/lib/python3.11/site-packages/fairchem/core/common/relaxation/ase_utils.py:200: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  checkpoint = torch.load(checkpoint_path, map_location=torch.device("cpu"))
INFO:root:local rank base: 0
INFO:root:amp: false
cmd:
  checkpoint_dir: /data2_1/jinvk/25_Fe/stage/checkpoints/2025-09-04-19-18-40
  commit: core:None,experimental:NA
  identifier: ''
  logs_dir: /data2_1/jinvk/25_Fe/stage/logs/wandb/2025-09-04-19-18-40
  print_every: 100
  results_dir: /data2_1/jinvk/25_Fe/stage/results/2025-09-04-19-18-40
  seed: null
  timestamp_id: 2025-09-04-19-18-40
  version: 1.10.0
dataset:
  a2g_args:
    r_energy: true
    r_forces: true
    r_stress: true
  format: ase_db
  metadata_path: ''
  transforms:
    element_references: ''
    normalizer:
      energy:
        mean: 0.0
        stdev: 0.6274358
      forces:
        mean: 0.0
        stdev: 0.6274358
      stress:
        mean: 0.0
        stdev: 0.6274358
evaluation_metrics:
  metrics:
    energy:
    - mae
    - per_atom_mae
    forces:
    - mae
    - cosine_similarity
    stress:
    - mae
  primary_metric: forces_mae
gp_gpus: null
gpus: 1
logger: wandb
loss_functions:
- energy:
    coefficient: 20
    fn: per_atom_mae
- forces:
    coefficient: 20
    fn: l2mae
- stress:
    coefficient: 5
    fn: mae
model:
  backbone:
    act_type: gate
    cutoff: 6.0
    direct_forces: false
    distance_function: gaussian
    edge_channels: 128
    hidden_channels: 128
    lmax: 3
    max_neighbors: 300
    max_num_elements: 100
    mlp_type: spectral
    mmax: 2
    model: esen_backbone
    norm_type: rms_norm_sh
    num_distance_basis: 64
    num_layers: 10
    otf_graph: true
    regress_forces: true
    regress_stress: true
    sphere_channels: 128
    use_envelope: true
    use_pbc: true
    use_pbc_single: true
  heads:
    mptrj:
      module: esen_mlp_efs_head
  name: hydra
  otf_graph: true
  pass_through_head_outputs: true
optim:
  batch_size: 4
  clip_grad_norm: 100
  ema_decay: 0.999
  eval_batch_size: 4
  eval_every: 5000
  load_balancing: atoms
  lr_initial: 0.0004
  max_epochs: 1
  num_workers: 4
  optimizer: AdamW
  optimizer_params:
    weight_decay: 0.001
  scheduler: LambdaLR
  scheduler_params:
    epochs: 85271
    lambda_type: cosine
    lr: 0.0004
    lr_min_factor: 0.1
    warmup_epochs: 8527
    warmup_factor: 0.2
outputs:
  energy:
    level: system
    property: energy
  forces:
    eval_on_free_atoms: true
    level: atom
    property: forces
    train_on_free_atoms: true
  stress:
    level: system
    property: stress
relax_dataset: {}
slurm: {}
task: {}
test_dataset: {}
trainer: ocp
val_dataset: {}

INFO:root:Loading model: hydra
/home/jinvk/environment/venv/febench-esen/lib/python3.11/site-packages/fairchem/core/models/esen/esen.py:91: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  Jd_list = torch.load(os.path.join(os.path.dirname(__file__), "Jd.pt"))
INFO:root:Loaded HydraModel with 30161153 parameters.
INFO:root:Loading checkpoint in inference-only mode, not loading keys associated with trainer state!
WARNING:root:No seed has been set in modelcheckpoint or OCPCalculator! Results may not be reproducible on re-run
[eSEN] model=esen, modal=oam
[eSEN] potential path: /data2/shared_data/cps/eSEN/esen_30m_oam.pt
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:13<00:00, 13.72s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:13<00:00, 13.72s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:20<00:00, 20.01s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:20<00:00, 20.01s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:58<13:39, 58.56s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [04:23<31:17, 144.45s/it]processing carbon in iron ...:  20%|██        | 3/15 [04:59<18:59, 95.00s/it] processing carbon in iron ...:  27%|██▋       | 4/15 [08:22<25:13, 137.61s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [09:22<18:16, 109.62s/it]processing carbon in iron ...:  40%|████      | 6/15 [10:26<14:06, 94.11s/it] processing carbon in iron ...:  47%|████▋     | 7/15 [11:36<11:31, 86.42s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [15:07<14:42, 126.06s/it]processing carbon in iron ...:  60%|██████    | 9/15 [17:14<12:37, 126.23s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [19:38<10:59, 131.82s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [21:45<08:41, 130.29s/it]processing carbon in iron ...:  80%|████████  | 12/15 [23:50<06:26, 128.78s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [27:22<05:08, 154.04s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [29:02<02:17, 137.49s/it]processing carbon in iron ...: 100%|██████████| 15/15 [29:58<00:00, 112.88s/it]processing carbon in iron ...: 100%|██████████| 15/15 [29:58<00:00, 119.87s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:36<04:54, 36.80s/it]processing transition metals ...:  22%|██▏       | 2/9 [01:20<04:44, 40.70s/it]processing transition metals ...:  33%|███▎      | 3/9 [02:12<04:36, 46.08s/it]processing transition metals ...:  44%|████▍     | 4/9 [05:56<09:40, 116.14s/it]processing transition metals ...:  56%|█████▌    | 5/9 [06:48<06:12, 93.08s/it] processing transition metals ...:  67%|██████▋   | 6/9 [07:52<04:09, 83.29s/it]processing transition metals ...:  78%|███████▊  | 7/9 [08:32<02:17, 68.94s/it]processing transition metals ...:  89%|████████▉ | 8/9 [12:11<01:56, 116.85s/it]processing transition metals ...: 100%|██████████| 9/9 [13:11<00:00, 99.07s/it] processing transition metals ...: 100%|██████████| 9/9 [13:11<00:00, 87.95s/it]
/home/jinvk/environment/venv/febench-esen/lib/python3.11/site-packages/fairchem/core/models/scn/spherical_harmonics.py:23: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  _Jd = torch.load(os.path.join(os.path.dirname(__file__), "Jd.pt"))
/home/jinvk/environment/venv/febench-esen/lib/python3.11/site-packages/fairchem/core/models/equiformer_v2/wigner.py:10: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  _Jd = torch.load(os.path.join(os.path.dirname(__file__), "Jd.pt"))
/home/jinvk/environment/venv/febench-esen/lib/python3.11/site-packages/fairchem/core/models/escn/so3.py:23: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  _Jd = torch.load(os.path.join(os.path.dirname(__file__), "Jd.pt"))
/home/jinvk/environment/venv/febench-esen/lib/python3.11/site-packages/fairchem/core/common/relaxation/ase_utils.py:200: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  checkpoint = torch.load(checkpoint_path, map_location=torch.device("cpu"))
INFO:root:local rank base: 0
INFO:root:amp: false
cmd:
  checkpoint_dir: /data2_1/jinvk/25_Fe/stage/checkpoints/2025-09-04-20-03-28
  commit: core:None,experimental:NA
  identifier: ''
  logs_dir: /data2_1/jinvk/25_Fe/stage/logs/wandb/2025-09-04-20-03-28
  print_every: 100
  results_dir: /data2_1/jinvk/25_Fe/stage/results/2025-09-04-20-03-28
  seed: null
  timestamp_id: 2025-09-04-20-03-28
  version: 1.10.0
dataset:
  a2g_args:
    r_energy: true
    r_forces: true
    r_stress: true
  format: ase_db
  lin_ref: ''
  metadata_path: ''
  normalizer:
    energy:
      mean: 0.0
      stdev: 4.980640411376953
    forces:
      mean: 0.0
      stdev: 4.980640411376953
    stress:
      mean: 0.0
      stdev: 4.980640411376953
evaluation_metrics:
  metrics:
    energy:
    - mae
    - per_atom_mae
    forces:
    - mae
    - forcesx_mae
    - forcesy_mae
    - forcesz_mae
    - cosine_similarity
    stress:
    - mae
  primary_metric: forces_mae
gp_gpus: null
gpus: 1
logger: wandb
loss_functions:
- energy:
    coefficient: 20
    fn: per_atom_mae
- forces:
    coefficient: 20
    fn: l2mae
- stress:
    coefficient: 5
    fn: mae
model:
  backbone:
    act_type: gate
    cutoff: 6.0
    direct_forces: false
    distance_function: gaussian
    edge_channels: 128
    hidden_channels: 128
    lmax: 3
    max_neighbors: 300
    max_num_elements: 100
    mlp_type: spectral
    mmax: 2
    model: esen_backbone
    norm_type: rms_norm_sh
    num_distance_basis: 64
    num_layers: 10
    otf_graph: true
    regress_forces: true
    regress_stress: true
    sphere_channels: 128
    use_envelope: true
    use_pbc: true
    use_pbc_single: true
  heads:
    efs:
      module: esen_mlp_efs_head_dens
  name: hydra
  otf_graph: true
  pass_through_head_outputs: true
optim:
  batch_size: 8
  clip_grad_norm: 100
  ema_decay: 0.999
  eval_batch_size: 8
  eval_every: 10000
  load_balancing: atoms
  lr_initial: 0.0003
  max_epochs: 2
  num_workers: 4
  optimizer: AdamW
  optimizer_params:
    weight_decay: 0.001
  scheduler: LambdaLR
  scheduler_params:
    epochs: 393848
    lambda_type: cosine
    lr: 0.0003
    lr_min_factor: 0.05
    warmup_epochs: 1969
    warmup_factor: 0.2
outputs:
  energy:
    level: system
    property: energy
  forces:
    eval_on_free_atoms: true
    level: atom
    property: forces
    train_on_free_atoms: true
  stress:
    level: system
    property: stress
relax_dataset: {}
slurm: {}
task: {}
test_dataset: {}
trainer: ocp
val_dataset: {}

INFO:root:Loading model: hydra
/home/jinvk/environment/venv/febench-esen/lib/python3.11/site-packages/fairchem/core/models/esen/esen.py:91: FutureWarning: You are using `torch.load` with `weights_only=False` (the current default value), which uses the default pickle module implicitly. It is possible to construct malicious pickle data which will execute arbitrary code during unpickling (See https://github.com/pytorch/pytorch/blob/main/SECURITY.md#untrusted-models for more details). In a future release, the default value for `weights_only` will be flipped to `True`. This limits the functions that could be executed during unpickling. Arbitrary objects will no longer be allowed to be loaded via this mode unless they are explicitly allowlisted by the user via `torch.serialization.add_safe_globals`. We recommend you start setting `weights_only=True` for any use case where you don't have full control of the loaded file. Please open an issue on GitHub for any issues related to this experimental feature.
  Jd_list = torch.load(os.path.join(os.path.dirname(__file__), "Jd.pt"))
INFO:root:Loaded HydraModel with 30161410 parameters.
INFO:root:Loading checkpoint in inference-only mode, not loading keys associated with trainer state!
WARNING:root:No seed has been set in modelcheckpoint or OCPCalculator! Results may not be reproducible on re-run
[eSEN] model=esen, modal=omat
[eSEN] potential path: /data2/shared_data/cps/eSEN/esen_30m_omat.pt
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:17<00:00, 17.37s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:17<00:00, 17.37s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:28<00:00, 28.80s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:28<00:00, 28.80s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:40<09:33, 40.96s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [02:05<14:23, 66.40s/it]processing carbon in iron ...:  20%|██        | 3/15 [02:51<11:28, 57.34s/it]processing carbon in iron ...:  27%|██▋       | 4/15 [04:09<11:57, 65.21s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [06:09<14:09, 84.97s/it]processing carbon in iron ...:  40%|████      | 6/15 [06:58<10:55, 72.80s/it]processing carbon in iron ...:  47%|████▋     | 7/15 [07:39<08:20, 62.52s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [11:10<12:48, 109.80s/it]processing carbon in iron ...:  60%|██████    | 9/15 [12:55<10:49, 108.27s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [14:55<09:19, 111.81s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [16:36<07:14, 108.57s/it]processing carbon in iron ...:  80%|████████  | 12/15 [20:06<06:58, 139.53s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [23:37<05:22, 161.04s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [24:36<02:10, 130.13s/it]processing carbon in iron ...: 100%|██████████| 15/15 [25:24<00:00, 105.51s/it]processing carbon in iron ...: 100%|██████████| 15/15 [25:24<00:00, 101.63s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:29<03:59, 29.90s/it]processing transition metals ...:  22%|██▏       | 2/9 [01:05<03:54, 33.49s/it]processing transition metals ...:  33%|███▎      | 3/9 [01:45<03:37, 36.20s/it]processing transition metals ...:  44%|████▍     | 4/9 [02:28<03:15, 39.04s/it]processing transition metals ...:  56%|█████▌    | 5/9 [03:14<02:46, 41.63s/it]processing transition metals ...:  67%|██████▋   | 6/9 [04:14<02:23, 47.88s/it]processing transition metals ...:  78%|███████▊  | 7/9 [04:59<01:33, 46.82s/it]processing transition metals ...:  89%|████████▉ | 8/9 [07:27<01:19, 79.13s/it]processing transition metals ...: 100%|██████████| 9/9 [08:14<00:00, 68.97s/it]processing transition metals ...: 100%|██████████| 9/9 [08:14<00:00, 54.95s/it]
