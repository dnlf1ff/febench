GPU 3 assigned to the job
SLURM_NTASKS: 1
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
sourcing ~/.bash_profile\n
Removing mpi version 2021.6.0
Use `module list` to view any remaining dependent modules.
Removing mkl version 2022.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler version 2022.1.0
Use `module list` to view any remaining dependent modules.
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL
Removing oclfpga version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing compiler-rt version 2023.1.0
Use `module list` to view any remaining dependent modules.
Removing tbb version 2021.9.0
Use `module list` to view any remaining dependent modules.
Loading compiler version 2022.1.0
Loading tbb version 2021.9.0
Loading compiler-rt version 2023.1.0
Loading oclfpga version 2023.1.0
  Load "debugger" to debug DPC++ applications with the gdb-oneapi debugger.
  Load "dpl" for additional DPC++ APIs: https://github.com/oneapi-src/oneDPL

Loading compiler/2022.1.0
  Loading requirement: tbb/latest compiler-rt/latest oclfpga/latest
Loading mkl version 2022.1.0
Loading mpi version 2021.6.0
[SevenNet] model=omni, modal=omat24
[SevenNet] potential path: /data2/shared_data/cps/omni/oob_v6/checkpoint_1.pth
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:13<00:00, 13.00s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:13<00:00, 13.00s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:10<00:00, 10.57s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:10<00:00, 10.58s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:38<08:54, 38.19s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [01:42<11:34, 53.40s/it]processing carbon in iron ...:  20%|██        | 3/15 [02:05<07:55, 39.59s/it]processing carbon in iron ...:  27%|██▋       | 4/15 [03:08<08:58, 48.96s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [03:40<07:07, 42.78s/it]processing carbon in iron ...:  40%|████      | 6/15 [04:13<05:55, 39.55s/it]processing carbon in iron ...:  47%|████▋     | 7/15 [04:49<05:06, 38.26s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [06:10<06:03, 51.92s/it]processing carbon in iron ...:  60%|██████    | 9/15 [07:20<05:45, 57.66s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [08:38<05:19, 63.88s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [10:00<04:37, 69.30s/it]processing carbon in iron ...:  80%|████████  | 12/15 [11:15<03:33, 71.06s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [13:12<02:49, 84.99s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [14:01<01:14, 74.28s/it]processing carbon in iron ...: 100%|██████████| 15/15 [14:20<00:00, 57.59s/it]processing carbon in iron ...: 100%|██████████| 15/15 [14:20<00:00, 57.39s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:14<01:53, 14.19s/it]processing transition metals ...:  22%|██▏       | 2/9 [00:30<01:49, 15.70s/it]processing transition metals ...:  33%|███▎      | 3/9 [00:50<01:45, 17.51s/it]processing transition metals ...:  44%|████▍     | 4/9 [01:07<01:26, 17.28s/it]processing transition metals ...:  56%|█████▌    | 5/9 [01:28<01:13, 18.48s/it]processing transition metals ...:  67%|██████▋   | 6/9 [01:55<01:04, 21.55s/it]processing transition metals ...:  78%|███████▊  | 7/9 [02:13<00:40, 20.22s/it]processing transition metals ...:  89%|████████▉ | 8/9 [02:34<00:20, 20.57s/it]processing transition metals ...: 100%|██████████| 9/9 [02:53<00:00, 20.12s/it]processing transition metals ...: 100%|██████████| 9/9 [02:53<00:00, 19.29s/it]
[SevenNet] model=omni, modal=mpa
[SevenNet] potential path: /data2/shared_data/cps/omni/oob_v6/checkpoint_1.pth
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.89s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.89s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:10<00:00, 10.94s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:10<00:00, 10.94s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:26<06:15, 26.79s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [01:25<09:55, 45.85s/it]processing carbon in iron ...:  20%|██        | 3/15 [01:45<06:43, 33.60s/it]processing carbon in iron ...:  27%|██▋       | 4/15 [02:43<07:59, 43.60s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [03:11<06:18, 37.80s/it]processing carbon in iron ...:  40%|████      | 6/15 [03:43<05:23, 35.90s/it]processing carbon in iron ...:  47%|████▋     | 7/15 [04:15<04:36, 34.58s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [05:29<05:29, 47.03s/it]processing carbon in iron ...:  60%|██████    | 9/15 [06:31<05:11, 51.84s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [07:40<04:45, 57.20s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [08:44<03:57, 59.27s/it]processing carbon in iron ...:  80%|████████  | 12/15 [09:49<03:02, 60.91s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [11:42<02:33, 76.63s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [12:23<01:05, 65.81s/it]processing carbon in iron ...: 100%|██████████| 15/15 [12:42<00:00, 51.75s/it]processing carbon in iron ...: 100%|██████████| 15/15 [12:42<00:00, 50.81s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:18<02:29, 18.67s/it]processing transition metals ...:  22%|██▏       | 2/9 [00:36<02:08, 18.39s/it]processing transition metals ...:  33%|███▎      | 3/9 [00:59<02:00, 20.13s/it]processing transition metals ...:  44%|████▍     | 4/9 [01:20<01:42, 20.55s/it]processing transition metals ...:  56%|█████▌    | 5/9 [01:44<01:27, 21.94s/it]processing transition metals ...:  67%|██████▋   | 6/9 [02:07<01:07, 22.40s/it]processing transition metals ...:  78%|███████▊  | 7/9 [02:27<00:42, 21.39s/it]processing transition metals ...:  89%|████████▉ | 8/9 [02:51<00:22, 22.23s/it]processing transition metals ...: 100%|██████████| 9/9 [03:12<00:00, 21.78s/it]processing transition metals ...: 100%|██████████| 9/9 [03:12<00:00, 21.34s/it]
[SevenNet] model=omni, modal=matpes_pbe
[SevenNet] potential path: /data2/shared_data/cps/omni/oob_v6/checkpoint_1.pth
processing calculations for pure Iron ...
relaxing bulk structure ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.73s/it]relaxing bulk structure ...: 100%|██████████| 1/1 [00:08<00:00,  8.73s/it]
relaxing sturcture with one vacancy ...:   0%|          | 0/1 [00:00<?, ?it/s]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:12<00:00, 12.75s/it]relaxing sturcture with one vacancy ...: 100%|██████████| 1/1 [00:12<00:00, 12.75s/it]
processing carbon in iron ...:   0%|          | 0/15 [00:00<?, ?it/s]processing carbon in iron ...:   7%|▋         | 1/15 [00:32<07:28, 32.06s/it]processing carbon in iron ...:  13%|█▎        | 2/15 [01:33<10:42, 49.44s/it]processing carbon in iron ...:  20%|██        | 3/15 [01:58<07:38, 38.20s/it]processing carbon in iron ...:  27%|██▋       | 4/15 [02:56<08:27, 46.10s/it]processing carbon in iron ...:  33%|███▎      | 5/15 [03:28<06:50, 41.04s/it]processing carbon in iron ...:  40%|████      | 6/15 [03:58<05:35, 37.32s/it]processing carbon in iron ...:  47%|████▋     | 7/15 [04:30<04:43, 35.40s/it]processing carbon in iron ...:  53%|█████▎    | 8/15 [05:36<05:16, 45.20s/it]processing carbon in iron ...:  60%|██████    | 9/15 [06:35<04:57, 49.63s/it]processing carbon in iron ...:  67%|██████▋   | 10/15 [07:46<04:40, 56.06s/it]processing carbon in iron ...:  73%|███████▎  | 11/15 [08:49<03:52, 58.15s/it]processing carbon in iron ...:  80%|████████  | 12/15 [09:57<03:03, 61.32s/it]processing carbon in iron ...:  87%|████████▋ | 13/15 [12:28<02:56, 88.35s/it]processing carbon in iron ...:  93%|█████████▎| 14/15 [13:12<01:15, 75.13s/it]processing carbon in iron ...: 100%|██████████| 15/15 [13:32<00:00, 58.50s/it]processing carbon in iron ...: 100%|██████████| 15/15 [13:32<00:00, 54.19s/it]
processing transition metals ...:   0%|          | 0/9 [00:00<?, ?it/s]processing transition metals ...:  11%|█         | 1/9 [00:16<02:11, 16.46s/it]processing transition metals ...:  22%|██▏       | 2/9 [00:37<02:14, 19.28s/it]processing transition metals ...:  33%|███▎      | 3/9 [00:58<01:59, 19.85s/it]processing transition metals ...:  44%|████▍     | 4/9 [01:15<01:33, 18.71s/it]processing transition metals ...:  56%|█████▌    | 5/9 [01:42<01:27, 21.80s/it]processing transition metals ...:  67%|██████▋   | 6/9 [02:11<01:12, 24.16s/it]processing transition metals ...:  78%|███████▊  | 7/9 [02:28<00:43, 21.99s/it]processing transition metals ...:  89%|████████▉ | 8/9 [02:49<00:21, 21.66s/it]processing transition metals ...: 100%|██████████| 9/9 [03:14<00:00, 22.68s/it]processing transition metals ...: 100%|██████████| 9/9 [03:14<00:00, 21.63s/it]
